from flask import Flask, render_template, request, jsonify
from nltk.chat.util import Chat, reflections

app = Flask(__name__)

# Define a set of patterns and responses for the chatbot
patterns = [
    (r'hi|hello|hey', ['Hello!', 'Hi there!', 'Hey!']),
    (r'how are you', ['I am doing well, thank you.', 'I am good. How about you?']),
    (r'what is your name', ['I am a chatbot. You can call me ChatGPT.', 'I am ChatGPT, your virtual assistant.']),
    (r'bye|goodbye', ['Goodbye!', 'See you later!', 'Bye!']),
    (r'your favorite color', ['I don\'t have a favorite color. I am a text-based entity.']),
    (r'how old are you', ['I don\'t have an age. I am a program.']),
    (r'where are you from', ['I exist in the digital realm.']),
    (r'what can you do', ['I can answer questions, engage in conversation, and assist you with information.']),
    (r'(.*)', ["I'm sorry, I didn't understand that. Can you please rephrase?"])
]

# Create a chatbot using the patterns
chatbot = Chat(patterns, reflections)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get_response", methods=["POST"])
def get_response():
    user_input = request.get_json()["user_input"]
    response = chatbot.respond(user_input)
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=False)
